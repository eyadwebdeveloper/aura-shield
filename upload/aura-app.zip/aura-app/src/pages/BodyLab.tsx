import { useState } from "react";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { getBodySystems } from "../data/vitalsData";
import { Badge, PageHeader } from "../components/ui";
import ModelViewport from "../components/body/ModelViewport";
import "../styles/health.css";

export default function BodyLab() {
  const systems = getBodySystems();
  const [activeId, setActiveId] = useState<string | null>(null);
  return (
    <section className="health-page page body-lab-page">
      <PageHeader
        eyebrow="AURA / body"
        title="Body view"
        description="The human anatomy atlas, with the four systems that matter most far from Earth. Tap a structure — or the index beside it — and the matching system comes forward."
        actions={
          <Badge tone="info" dot>
            Human atlas
          </Badge>
        }
      />
      <div className="body-layout">
        <ModelViewport
          systems={systems}
          activeSystemId={activeId ?? undefined}
          onSelectSystem={setActiveId}
        />
        <aside className="panel body-context">
          <div className="eyebrow">Systems index</div>
          <h2>Choose a system</h2>
          <p>
            Hover or focus an entry to bring it forward on the atlas. Tap a
            structure or a row to open the system detail.
          </p>
          <ul className="body-context-list">
            {systems.map((system) => (
              <li
                key={system.id}
                className={system.id === activeId ? "active" : ""}
                onMouseEnter={() => setActiveId(system.id)}
              >
                <Link
                  to={`/system/${system.id}`}
                  onFocus={() => setActiveId(system.id)}
                >
                  <span>{system.name}</span>
                  <strong>
                    {system.statusLabel}{" "}
                    <ChevronRight
                      size={14}
                      style={{ display: "inline", verticalAlign: "-2px" }}
                    />
                  </strong>
                </Link>
              </li>
            ))}
          </ul>
          <div className="demo-disclaimer">
            BodyParts3D reference anatomy, shown for orientation. Plan scores
            and labels are demo data, not a clinical reading.
          </div>
        </aside>
      </div>
    </section>
  );
}
