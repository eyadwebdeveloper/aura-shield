import { useEffect, useRef, useState } from "react";
import type { BodySystem } from "../../data/vitalsData";
import { SYSTEM_MAP, type SystemId } from "../../lib/anatomy/types";
import { useSettingsStore } from "../../stores/settingsStore";
import { AnatomyEngine, type HoverInfo } from "./anatomyEngine";

/**
 * BodyParts3D human atlas in the AURA viewport.
 * Geometry: BodyParts3D 4.0, © Database Center for Life Science, CC BY 4.0.
 * The four workspace systems map onto atlas systems so the existing
 * index, dashboard, and system pages keep working.
 */

const AURA_SYSTEMS: Record<string, { atlas: SystemId[]; accent: string }> = {
  cardiovascular: {
    atlas: ["cardiac", "arterial", "venous"],
    accent: "#b4483f",
  },
  skeletal: {
    atlas: ["skeletal", "muscular"],
    accent: "#8a7340",
  },
  nervous: {
    atlas: ["nervous", "brain", "sensory"],
    accent: "#4d5d78",
  },
  immune: {
    atlas: ["lymphatic"],
    accent: "#2f6a52",
  },
};

const ATLAS_TO_AURA: Record<string, string> = Object.fromEntries(
  Object.entries(AURA_SYSTEMS).flatMap(([id, spec]) =>
    spec.atlas.map((system) => [system, id]),
  ),
);

/** Standing body without the skin shell, matching the atlas default. */
const RESTING: SystemId[] = [
  "skeletal",
  "muscular",
  "cardiac",
  "sensory",
  "arterial",
  "venous",
  "nervous",
  "brain",
  "respiratory",
  "digestive",
  "urinary",
  "lymphatic",
  "endocrine",
  "connective",
];

type Props = {
  systems?: BodySystem[];
  activeSystemId?: string | null;
  onSelectSystem?: (id: string) => void;
  onError?: () => void;
};

export default function AtlasBodyScene({
  activeSystemId = null,
  onSelectSystem,
  onError,
}: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<AnatomyEngine | null>(null);
  const selectRef = useRef(onSelectSystem);
  const errorRef = useRef(onError);
  const animationsEnabled = useSettingsStore((s) => s.animationsEnabled);
  const [hover, setHover] = useState<HoverInfo | null>(null);
  const [progress, setProgress] = useState<{ loaded: number; total: number } | null>(
    null,
  );

  selectRef.current = onSelectSystem;
  errorRef.current = onError;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let engine: AnatomyEngine;
    try {
      engine = new AnatomyEngine(host, {
        onHover: (info) => setHover(info),
        onPick: (_id, system) => {
          if (!system) return;
          const aura = ATLAS_TO_AURA[system];
          if (aura) selectRef.current?.(aura);
        },
        onActivate: () => {},
        onProgress: (next) => setProgress(next),
        onError: () => errorRef.current?.(),
      });
    } catch {
      onError?.();
      return;
    }
    engine.attachResizeObserver();
    engineRef.current = engine;
    void engine.setAtlas("/models/atlas.json");
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // Mount once. Later prop changes go through the effect below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    const spec = activeSystemId ? AURA_SYSTEMS[activeSystemId] : undefined;
    engine.setAccent(spec?.accent ?? "#24554b");
    engine.setState({
      visible: RESTING,
      selected: [],
      emphasis: spec?.atlas ?? [],
      isolate: false,
      explode: 0,
      view: "three-quarter",
      autoRotate: animationsEnabled && !spec,
      reset: 0,
      focus: 0,
    });
  }, [activeSystemId, animationsEnabled]);

  return (
    <div ref={hostRef} className="body-scene-host">
      {progress && (
        <div className="atlas-progress">
          Opening the atlas · {progress.loaded}/{progress.total}
        </div>
      )}
      {hover && (
        <div className="atlas-hover" style={{ left: hover.x, top: hover.y }}>
          {hover.name}
          <span>{SYSTEM_MAP[hover.system]?.name ?? hover.system}</span>
        </div>
      )}
    </div>
  );
}
