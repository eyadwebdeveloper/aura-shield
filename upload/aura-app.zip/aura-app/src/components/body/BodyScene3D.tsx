import { useEffect, useRef } from "react";
import * as THREE from "three";
import type { BodySystem } from "../../data/vitalsData";
import { useSettingsStore } from "../../stores/settingsStore";

/**
 * Simple, built-in Three.js body figure — no external model, no addons.
 * Plain primitives (capsules, spheres, torus) form a calm microgravity
 * figure; four body systems are highlighted as small markers that can
 * be tapped (raycast) to select the system.
 */

const SYSTEM_COLORS: Record<string, number> = {
  cardiovascular: 0xd17969,
  skeletal: 0xa59b71,
  nervous: 0x7d869b,
  immune: 0x5a8c76,
};

type Props = {
  systems?: BodySystem[];
  activeSystemId?: string | null;
  onSelectSystem?: (id: string) => void;
  onError?: () => void;
};

export default function BodyScene3D({
  activeSystemId = null,
  onSelectSystem,
  onError,
}: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef(activeSystemId);
  const selectRef = useRef(onSelectSystem);
  const animationsEnabled = useSettingsStore((s) => s.animationsEnabled);
  const motionRef = useRef(animationsEnabled);
  activeRef.current = activeSystemId;
  selectRef.current = onSelectSystem;
  motionRef.current = animationsEnabled;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      onError?.();
      return;
    }

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(resource: T): T => {
      disposables.push(resource);
      return resource;
    };

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.touchAction = "none";
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 50);

    scene.add(new THREE.HemisphereLight(0xf4f6ee, 0xcfd8cc, 1.15));
    const key = new THREE.DirectionalLight(0xffffff, 1.05);
    key.position.set(3, 4.5, 2.5);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xc1ebc9, 0.55);
    rim.position.set(-3, 2.5, -3);
    scene.add(rim);

    // ---- The figure -------------------------------------------------------
    const figure = new THREE.Group();
    scene.add(figure);

    const bodyMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xe9efe6,
        roughness: 0.62,
        metalness: 0.04,
        transparent: true,
        opacity: 0.96,
      }),
    );
    const suitMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xcfd9cf,
        roughness: 0.7,
        metalness: 0.08,
        transparent: true,
        opacity: 0.96,
      }),
    );
    const proxyMat = track(
      new THREE.MeshBasicMaterial({
        transparent: true,
        opacity: 0,
        depthWrite: false,
      }),
    );

    const addMesh = (
      geometry: THREE.BufferGeometry,
      material: THREE.Material,
      position: [number, number, number],
      options: { rotation?: [number, number, number]; scale?: [number, number, number]; parent?: THREE.Object3D } = {},
    ) => {
      const mesh = new THREE.Mesh(track(geometry), material);
      mesh.position.set(...position);
      if (options.rotation) mesh.rotation.set(...options.rotation);
      if (options.scale) mesh.scale.set(...options.scale);
      (options.parent ?? figure).add(mesh);
      return mesh;
    };

    const sphere = (r: number) => new THREE.SphereGeometry(r, 18, 14);
    const capsule = (r: number, len: number) =>
      new THREE.CapsuleGeometry(r, len, 5, 14);
    const cylinder = (r: number, len: number) =>
      new THREE.CylinderGeometry(r, r, len, 12);

    // Head, neck, helmet seal
    const head = addMesh(sphere(0.13), bodyMat, [0, 1.585, 0]);
    addMesh(sphere(0.135), suitMat, [0, 1.585, -0.005], { scale: [1.005, 1.02, 1.02] });
    addMesh(
      new THREE.TorusGeometry(0.138, 0.012, 10, 40),
      suitMat,
      [0, 1.525, 0],
      { rotation: [Math.PI / 2, 0, 0] },
    );
    addMesh(cylinder(0.05, 0.08), bodyMat, [0, 1.455, 0]);

    // Torso and pelvis
    addMesh(capsule(0.17, 0.26), bodyMat, [0, 1.14, 0]);
    addMesh(capsule(0.15, 0.06), bodyMat, [0, 0.95, 0]);

    // Shoulders and arms
    addMesh(sphere(0.1), bodyMat, [-0.2, 1.36, 0]);
    addMesh(sphere(0.1), bodyMat, [0.2, 1.36, 0]);
    for (const side of [-1, 1]) {
      addMesh(capsule(0.052, 0.2), bodyMat, [side * 0.245, 1.22, 0], {
        rotation: [0, 0, side * 0.12],
      });
      addMesh(capsule(0.045, 0.19), bodyMat, [side * 0.275, 0.94, 0], {
        rotation: [0, 0, -side * 0.14],
      });
      addMesh(sphere(0.05), bodyMat, [side * 0.3, 0.79, 0]);
      // Legs
      addMesh(capsule(0.075, 0.26), bodyMat, [side * 0.1, 0.68, 0]);
      addMesh(capsule(0.06, 0.26), bodyMat, [side * 0.1, 0.3, 0]);
    }

    // ---- System markers ---------------------------------------------------
    const markerMats: Record<string, THREE.MeshStandardMaterial> = {};
    const markers: THREE.Mesh[] = [];
    const systemMeshes: Record<string, THREE.Mesh[]> = {};

    const markerMat = (systemId: string) => {
      if (!markerMats[systemId]) {
        const color = SYSTEM_COLORS[systemId] ?? 0x5a8c76;
        markerMats[systemId] = track(
          new THREE.MeshStandardMaterial({
            color,
            emissive: color,
            emissiveIntensity: 0.03,
            roughness: 0.45,
            metalness: 0.1,
            transparent: true,
            opacity: 1,
          }),
        );
        systemMeshes[systemId] = [];
      }
      return markerMats[systemId];
    };

    const marker = (
      systemId: string,
      geometry: THREE.BufferGeometry,
      position: [number, number, number],
      options: { rotation?: [number, number, number]; scale?: [number, number, number] } = {},
    ) => {
      const mesh = addMesh(geometry, markerMat(systemId), position, options);
      mesh.userData.systemId = systemId;
      markers.push(mesh);
      systemMeshes[systemId].push(mesh);
      return mesh;
    };

    // Cardiovascular — heart + vessel column
    marker("cardiovascular", sphere(0.058), [-0.05, 1.24, 0.125], {
      scale: [1, 1.18, 1],
    });
    marker("cardiovascular", capsule(0.013, 0.22), [0.02, 1.13, 0.14]);
    marker("cardiovascular", sphere(0.032), [0.05, 1.335, 0.09]);

    // Skeletal — spine beads, pelvis ring, long bones
    for (let i = 0; i < 7; i += 1) {
      const t = i / 6;
      marker("skeletal", sphere(0.026), [0, 0.99 + t * 0.32, -0.132]);
    }
    marker(
      "skeletal",
      new THREE.TorusGeometry(0.11, 0.013, 8, 30),
      [0, 0.95, 0],
      { rotation: [Math.PI / 2, 0, 0] },
    );
    for (const side of [-1, 1]) {
      marker("skeletal", cylinder(0.018, 0.28), [side * 0.1, 0.68, 0]);
      marker("skeletal", cylinder(0.016, 0.28), [side * 0.1, 0.3, 0]);
    }

    // Nervous — brain, eyes, vestibular organs
    marker("nervous", sphere(0.072), [0, 1.6, 0.01]);
    marker("nervous", sphere(0.024), [-0.048, 1.6, 0.118]);
    marker("nervous", sphere(0.024), [0.048, 1.6, 0.118]);
    marker("nervous", sphere(0.02), [-0.128, 1.585, 0.012]);
    marker("nervous", sphere(0.02), [0.128, 1.585, 0.012]);

    // Immune — lymph node clusters
    const NODES: Array<[number, number, number]> = [
      [-0.05, 1.465, 0.05],
      [0.05, 1.465, 0.05],
      [-0.19, 1.335, 0.03],
      [0.19, 1.335, 0.03],
      [0, 1.2, 0.155],
      [-0.062, 0.965, 0.05],
      [0.062, 0.965, 0.05],
    ];
    for (const position of NODES) {
      marker("immune", sphere(0.023), position);
    }

    // ---- Hit proxies (invisible, larger tap targets) ---------------------
    const proxies: THREE.Mesh[] = [];
    const proxy = (systemId: string, geometry: THREE.BufferGeometry, position: [number, number, number]) => {
      const mesh = addMesh(geometry, proxyMat, position);
      mesh.userData.systemId = systemId;
      proxies.push(mesh);
      return mesh;
    };
    proxy("cardiovascular", sphere(0.13), [0, 1.22, 0.1]);
    proxy("skeletal", capsule(0.07, 0.4), [0, 1.14, -0.05]);
    proxy("skeletal", sphere(0.09), [-0.1, 0.55, 0]);
    proxy("skeletal", sphere(0.09), [0.1, 0.55, 0]);
    proxy("nervous", sphere(0.15), [0, 1.59, 0]);
    proxy("immune", sphere(0.07), [0, 1.44, 0.05]);
    proxy("immune", sphere(0.07), [0, 1.2, 0.1]);
    proxy("immune", sphere(0.06), [0, 0.97, 0.03]);

    const raycastList = [...proxies, ...markers];
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    // ---- Orbit state ------------------------------------------------------
    const orbit = {
      yaw: 0.42,
      pitch: 1.3,
      dist: 3.35,
      yawT: 0.42,
      pitchT: 1.3,
      distT: 3.35,
    };
    const focus = new THREE.Vector3(0, 0.98, 0);
    let dragging = false;
    let moved = 0;
    let lastX = 0;
    let lastY = 0;
    let pinchDistance = 0;
    const activePointers = new Map<number, { x: number; y: number }>();
    let hoverId: string | null = null;

    const events = new AbortController();
    const { signal } = events;
    const el = renderer.domElement;

    const setPointer = (event: PointerEvent) => {
      const rect = el.getBoundingClientRect();
      pointer.set(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1,
      );
    };

    const pickSystem = (): string | null => {
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(raycastList, false);
      if (hits.length > 0) {
        const id = hits[0].object.userData.systemId as string | undefined;
        if (id) return id;
      }
      return null;
    };

    el.addEventListener(
      "pointerdown",
      (event) => {
        activePointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
        if (activePointers.size === 2) {
          const [a, b] = [...activePointers.values()];
          pinchDistance = Math.hypot(a.x - b.x, a.y - b.y);
          dragging = false;
          return;
        }
        dragging = true;
        moved = 0;
        lastX = event.clientX;
        lastY = event.clientY;
        el.setPointerCapture(event.pointerId);
      },
      { signal },
    );

    el.addEventListener(
      "pointermove",
      (event) => {
        if (activePointers.has(event.pointerId)) {
          activePointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
        }
        if (activePointers.size === 2) {
          const [a, b] = [...activePointers.values()];
          const next = Math.hypot(a.x - b.x, a.y - b.y);
          if (pinchDistance > 0) {
            orbit.distT = THREE.MathUtils.clamp(
              orbit.distT - (next - pinchDistance) * 0.01,
              2.1,
              5.2,
            );
          }
          pinchDistance = next;
          return;
        }
        if (dragging) {
          const dx = event.clientX - lastX;
          const dy = event.clientY - lastY;
          moved += Math.abs(dx) + Math.abs(dy);
          lastX = event.clientX;
          lastY = event.clientY;
          orbit.yawT -= dx * 0.005;
          orbit.pitchT = THREE.MathUtils.clamp(
            orbit.pitchT - dy * 0.004,
            0.8,
            1.62,
          );
          el.style.cursor = "grabbing";
          return;
        }
        setPointer(event);
        const hit = pickSystem();
        hoverId = hit;
        el.style.cursor = hit ? "pointer" : "grab";
      },
      { signal },
    );

    const releasePointer = (event: PointerEvent) => {
      const wasSingle = activePointers.size === 1;
      activePointers.delete(event.pointerId);
      if (activePointers.size < 2) pinchDistance = 0;
      if (!dragging) return;
      dragging = false;
      el.style.cursor = "grab";
      if (wasSingle && moved < 7) {
        setPointer(event);
        const hit = pickSystem();
        if (hit) selectRef.current?.(hit);
      }
    };
    el.addEventListener("pointerup", releasePointer, { signal });
    el.addEventListener("pointercancel", releasePointer, { signal });

    el.addEventListener(
      "wheel",
      (event) => {
        event.preventDefault();
        orbit.distT = THREE.MathUtils.clamp(
          orbit.distT + event.deltaY * 0.0022,
          2.1,
          5.2,
        );
      },
      { signal, passive: false },
    );

    // ---- Resize -----------------------------------------------------------
    const resize = () => {
      const width = host.clientWidth || 1;
      const height = host.clientHeight || 1;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    resize();

    // ---- Animation loop ---------------------------------------------------
    let raf = 0;
    let started = 0;

    const tick = (now: number) => {
      if (!started) started = now;
      const t = (now - started) / 1000;
      const motionOn = motionRef.current;

      // Damped orbit
      orbit.yaw += (orbit.yawT - orbit.yaw) * 0.14;
      orbit.pitch += (orbit.pitchT - orbit.pitch) * 0.14;
      orbit.dist += (orbit.distT - orbit.dist) * 0.14;
      camera.position.set(
        focus.x + orbit.dist * Math.sin(orbit.pitch) * Math.sin(orbit.yaw),
        focus.y + orbit.dist * Math.cos(orbit.pitch),
        focus.z + orbit.dist * Math.sin(orbit.pitch) * Math.cos(orbit.yaw),
      );
      camera.lookAt(focus);

      // Gentle microgravity float (skipped under reduced motion)
      if (motionOn) {
        figure.position.y = 0.02 + Math.sin(t * 0.7) * 0.018;
        figure.rotation.z = Math.sin(t * 0.23) * 0.02;
        head.position.y = 1.585 + Math.sin(t * 0.9) * 0.006;
      } else {
        figure.position.y = 0.02;
        figure.rotation.z = 0;
        head.position.y = 1.585;
      }

      // System highlight states
      const activeId = activeRef.current;
      for (const [systemId, meshes] of Object.entries(systemMeshes)) {
        const mat = markerMats[systemId];
        if (!mat) continue;
        const active = systemId === activeId;
        const hovered = !activeId && systemId === hoverId;
        const targetOpacity = activeId ? (active ? 1 : 0.26) : hovered ? 1 : 0.92;
        const pulse = motionOn ? 0.26 + 0.18 * (0.5 + 0.5 * Math.sin(t * 2.4)) : 0.34;
        const targetEmissive = active
          ? pulse
          : hovered
            ? 0.22
            : 0.03;
        mat.opacity += (targetOpacity - mat.opacity) * 0.12;
        mat.emissiveIntensity +=
          (targetEmissive - mat.emissiveIntensity) * 0.12;
        const scaleTarget = active
          ? motionOn
            ? 1 + 0.07 * (0.5 + 0.5 * Math.sin(t * 2.4))
            : 1.05
          : 1;
        for (const mesh of meshes) {
          const current = mesh.scale.x;
          mesh.scale.setScalar(current + (scaleTarget - current) * 0.12);
        }
      }

      const bodyTarget = activeId ? 0.6 : 0.96;
      bodyMat.opacity += (bodyTarget - bodyMat.opacity) * 0.1;
      suitMat.opacity += (bodyTarget - suitMat.opacity) * 0.1;

      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      events.abort();
      disposables.forEach((resource) => resource.dispose());
      renderer.dispose();
      if (renderer.domElement.parentNode === host) {
        host.removeChild(renderer.domElement);
      }
    };
    // Initial mount only — prop changes flow through refs above.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <div ref={hostRef} className="body-scene-host" />;
}
