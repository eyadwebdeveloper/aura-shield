# Astro-Shield: Rover & Debris Run — Final Web Build

A single Next.js web app containing **two interactive 3D experiences**:

1. **ASTRO-SHIELD** (default) — a fully 3D, playable "daily crew challenge" game.
   You pilot a hover rover through a Mars canyon, dodging debris, catching energy
   crystals, riding out magnetic interference and choosing between safe and storm
   routes — while the game quietly records NASA-standard clinical measures
   (PVT reaction times, vigilance lapses, impulsivity, adaptability, motivation)
   and shows the results as friendly crew cards plus a Flight Surgeon view.
2. **CORPUS** — an interactive 3D human anatomy explorer (the Atlas viewer built
   from the BodyParts3D / Human Reference Atlas data), streaming 2,234 meshes
   (male) / 1,220 meshes (female) with system explosion, isolation and raycast
   picking. Reach it via the app switcher in the header.

The two apps share the same rendering ideas (chunked geometry streaming,
per-part data textures, shader injection) — the game engine reuses the patterns
developed for the Atlas viewer.

---

## Requirements

- **Node.js ≥ 20.9** (or **Bun ≥ 1.1**)
- A modern browser with **WebGL 2** (Chrome / Edge / Firefox / Safari 15+)

## Quick start

```bash
npm install        # or: bun install
npm run dev        # or: bun dev
```

Open <http://localhost:3000>. The game starts by default; the header's
**Layers** button switches to the anatomy explorer (`#atlas` deep-links to it,
`#astro` back to the game).

> The dev server port is fixed to 3000 in `package.json` (`next dev -p 3000`).
> To change it, edit the `dev` script.

## Production build

```bash
npm run build
npm start
```

`next.config.ts` uses `output: 'standalone'`; the build script copies
`.next/static` and `public/` into `.next/standalone/`, and `npm start` runs the
standalone server (defaults to port 3000).

## Deploying as static-ish SPA (no Node server)

Both apps are pure client-side 3D (no API routes are used for gameplay). If you
prefer a fully static site without a Node server, you can serve the
`public/models/*.bin.gz` files from any CDN and keep everything else bundled by
the framework. The default `output: 'standalone'` works on any Node host
(Vercel, Render, Fly.io, a VPS with the included `Caddyfile`, …).

## Game controls

| Input | Action |
| --- | --- |
| ← → (or A / D) | Steer left / right |
| ↑ ↓ (or W / S) | Pitch up / down (hover altitude) |
| Space | Activate shield (or respond to radar ping) |
| P | Pause / resume |
| Mouse click / tap | Activate shield (mobile: on-screen joystick + shield button) |
| ← / → while fork is open | Choose Safe route (left) or Storm route (right) |

When controls are inverted by a **magnetic interference zone** (two 15-second
windows per run), steering axes flip — that adaptation cost is part of the
assessment.

## What the game silently measures

Every run produces a `SessionLog` (`src/components/astro/assessment.ts`) with
event-level timestamps. `computeMetrics()` derives the five clinical dimensions
and `computeBaseline()` compares them against the player's **rolling personal
baseline (median ± MAD of the last 10 sessions)**:

| # | Dimension | In-game trigger | Derived metric |
| --- | --- | --- | --- |
| 1 | PVT alertness (psychomotor vigilance) | Red meteoroids appear at random 2–10 s intervals on the rover's path | Median reaction time (ms) to shield |
| 2 | Vigilance lapses ("space fog") | Peripheral radar pings after quiet periods | Response > 500 ms or missed = lapse |
| 3 | Impulsivity / tension (POMS) | Green supply pods that look like red hazards | False alarms, premature shield presses |
| 4 | Spatial orientation / cognitive flexibility | 15 s magnetic control inversion | Seconds and collisions to adapt |
| 5 | Motivation / engagement | Safe vs storm route choice; post-hit recovery | Decision bias, post-error slowing |

Session history, streaks and baselines persist in `localStorage`
(`astroshield.sessions.v1`), so measures stabilize across days of play.

> **Note**: the cabin CO₂ values in the Flight Surgeon view are simulated
> telemetry for demonstration purposes; wire them to your real environmental
> system in `src/components/astro/Results.tsx`.

## Anatomy explorer (CORPUS)

- Switch with the header button or `#atlas` / `#astro` deep links.
- Streams the atlas in 15 gzipped chunks per body (`.bin.gz` via
  `DecompressionStream('gzip')`), one merged draw call per system chunk.
- Male (BodyParts3D 4.0, 2,234 meshes), Female (Human Reference Atlas v1.10,
  1,220 meshes) and Leg-muscles (donor muscles, 76 meshes) presets.
- Click a structure to isolate / explode systems; search included.

Model data © The Database Center for Life Science (CC BY 4.0) and the HuBMAP
Human Reference Atlas contributors (CC BY 4.0) — see the in-app credits.

## Project structure

```
├─ public/models/            # atlas manifests + 30 gzipped mesh chunks (69 MB)
├─ src/app/                  # Next.js shell (page.tsx = app switcher)
├─ src/components/astro/     # THE GAME (Three.js engine, world, rover, HUD, assessment)
│   ├─ engine.ts             # AstroEngine: render loop, director, collisions, scoring
│   ├─ world.ts              # Mars canyon: sky shader, scrolling terrain, rocks, dust
│   ├─ rover.ts              # procedural 3D hover rover + wheel/bank/mast animation
│   ├─ assessment.ts         # stealth PVT/POMS recorder, metrics, rolling baseline
│   ├─ Hud.tsx / Results.tsx # in-run HUD + crew & Flight Surgeon result cards
│   └─ store.ts / audio.ts   # zustand state + WebAudio synth SFX
├─ src/components/anatomy/   # CORPUS atlas viewer
├─ src/lib/anatomy/          # chunked binary loader + layout math
└─ prisma/                   # unused scaffold (schema only, no runtime use)
```

## Tech stack

Next.js 16 · React 19 · Three.js 0.187 · TypeScript · Tailwind CSS 4 ·
zustand · framer-motion · lucide-react

---

*Built as the final version of the Astro-Shield crew challenge web app.*
